Run:
1. prepareData 
2. RunBenchmarking
3. Check the benchmark.xls file - the first sheet contains results for modes of locomotion, the second contains the results for gestures.
